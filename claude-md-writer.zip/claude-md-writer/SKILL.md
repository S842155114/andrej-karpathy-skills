---
name: claude-md-writer
description: Generate and improve CLAUDE.md (or AGENTS.md) project instruction files. Use this skill whenever the user asks to create, write, generate, improve, update, or review a CLAUDE.md or AGENTS.md file — for a new project or an existing one. Also trigger when the user mentions "project instructions", "AI coding guidelines", "agent rules", or wants to make their AI assistant understand their project better. Don't wait for an explicit "CLAUDE.md" keyword — any request about setting up or refining per-project AI behavior should use this skill.
---

# CLAUDE.md Writer

Generate and improve project-specific CLAUDE.md/AGENTS.md files that give AI coding assistants the context they need to work effectively in any codebase.

## Core philosophy

This skill itself follows the Karpathy behavioral guidelines. Before writing anything, understand the project. Generate only what's needed. When improving, change only what matters. And always define what "done" looks like.

## When a CLAUDE.md is worth writing

A good CLAUDE.md pays for itself after 2-3 coding sessions. It's most valuable when:

- The project has non-obvious conventions (weird file layout, custom build steps)
- There are footguns the assistant keeps hitting (wrong test runner, wrong formatter)
- The stack has multiple viable approaches and you want consistency
- The project is large and an assistant needs help navigating it

For a 3-file script or a standard Create React App, a CLAUDE.md adds little value. Be honest about this — pushing back on unnecessary work IS the Simplicity First principle.

## Process

### Phase 1: Understand the project

Before writing a single line, build a mental model. Read these files when they exist:

1. **README.md** — what the project is, how to set it up
2. **package.json / Cargo.toml / go.mod / requirements.txt** — dependencies, scripts, toolchain
3. **tsconfig.json / pyproject.toml / Makefile** — compiler settings, build targets
4. **Top-level config files** — linter configs (.eslintrc, .prettierrc), CI configs (.github/workflows/), environment files (.env.example)
5. **Top-level directory listing** — to understand folder structure
6. **Existing CLAUDE.md / AGENTS.md / .cursor/rules/** — if improving, understand what's already there

Then scan a few representative source files. You're not auditing them — you're sampling to understand conventions: naming style, import patterns, error handling idioms, testing patterns, comment density.

If critical information can't be inferred from code, ask the user. But don't ask questions whose answers are already sitting in a README — that wastes the user's time. Questions worth asking:

- "Is there a preferred test command? I see both jest and vitest configs."
- "The API seems to have both REST and GraphQL endpoints — should assistants default to one?"
- "I see a `scripts/` folder with custom build tools — anything non-obvious about how they work?"

### Phase 2: Draft the CLAUDE.md

A CLAUDE.md has two layers:

**Layer 1: Behavioral foundation (always include)**
The Karpathy guidelines — Think Before Coding, Simplicity First, Surgical Changes, Goal-Driven Execution. These are the default behavior. Include them concisely, either as a reference or inline. The version in this plugin's `CLAUDE.md` is the canonical text; adapt it to the project's tone if needed but keep all four principles.

**Layer 2: Project-specific instructions (the valuable part)**
Only add sections that actually help. A section is worth including if removing it would cause an assistant to make a wrong choice at least once per session. Structure by what goes wrong most often:

```markdown
## Project overview
[One sentence. What this repo is and does. This is the "what am I looking at" answer.]

## Build & run
- `npm run dev` — start dev server on :3000
- `npm test` — run tests (jest, not vitest — the vitest config is deprecated)
- `npm run build` — production build to `dist/`

## Tech stack
[Key technologies, especially surprising ones. "React + TypeScript + Express" is expected; "uses Prisma with a legacy Sequelize migration half-done" is worth noting.]

## Code conventions
[Only non-obvious rules. Every project uses Prettier; mentioning it is noise. Noting that the project uses CSS Modules with a custom `*.module.css` convention IS useful.]

## Project structure
[Only if non-standard. Standard Next.js or Django layouts don't need explanation. A monorepo with unusual package boundaries does.]

## Testing
[How to run tests, what framework, any quirks. "Tests need a running Postgres — use `docker-compose up test-db` first."]

## Common pitfalls
[Things the assistant gets wrong. "Don't import from `@/components` directly — use `@/components/public` for shared components." "The `User` model has a soft-delete; always add `where: { deletedAt: null }`."]
```

#### Guidelines for each section

**Build & run commands**
- List the 3-5 commands someone needs 90% of the time
- Include any prerequisite steps (env vars, docker, database setup)
- If a command fails in a non-obvious way, note the fix

**Tech stack**
- List languages, frameworks, key libraries
- Highlight version constraints ("Python 3.10 only — no match statements")
- Note abandoned/legacy parts ("the `/admin` route is old Rails, don't touch it")

**Code conventions**
- Only non-obvious rules survive editing. Delete anything a linter already enforces.
- Focus on CHOICES: "we use `fetch` not axios", "CSS Modules, never styled-components"
- Naming conventions worth noting: "React components are `PascalCase.tsx`, hooks are `useCamelCase.ts`"

**Project structure**
- Describe the top-level directory layout IF it deviates from framework defaults
- For monorepos: explain package boundaries and shared code
- Don't list every folder — the assistant can `ls` too

**Testing**
- Exact commands to run tests (all, single file, watch mode)
- Any required setup (databases, mocks, fixtures)
- Coverage expectations if enforced

**Common pitfalls**
- This is the highest-ROI section. Read git history or ask the user: what do new contributors (human or AI) get wrong?
- Be specific: "The `config.ts` is generated — edit `config.template.ts` instead"
- One pitfall per bullet, with the fix

### Phase 3: Review with the user

After drafting, present the CLAUDE.md to the user with a summary of what's in each section and WHY. Ask:

- "Is anything missing that an assistant consistently gets wrong?"
- "Is anything here obvious enough to remove?"
- "Are the build commands correct? I inferred them from scripts in package.json."

Don't ask "does this look good?" — that questions invites rubber-stamping. Ask specific, answerable questions.

### Phase 4: Improving an existing CLAUDE.md

When improving rather than creating, follow the Surgical Changes principle:

1. Read the existing file carefully. Understand what each section does.
2. Read the project to check if the instructions still match reality. Commands change, conventions evolve, pitfalls get fixed.
3. Identify gaps: what does an assistant consistently get wrong that isn't covered?
4. Identify dead weight: rules for deleted code, conventions that linters now enforce, commands that no longer exist.
5. Make minimal changes — add what's missing, remove what's stale, fix what's wrong. Don't reorganize unless the structure is actively harmful.
6. Show a diff or summary of changes and explain the reasoning for each.

## Anti-patterns to avoid

The CLAUDE.md you generate should itself model the principles:

- **Don't add speculative rules.** "Always use TypeScript strict mode" when the project doesn't — that's aspiration, not description.
- **Don't duplicate what tools already enforce.** If Prettier runs on commit, don't write "use single quotes."
- **Don't write a novel.** A 50-line CLAUDE.md that covers the real footguns beats a 500-line one that documents the obvious.
- **Don't invent conventions.** If the project has no error handling pattern, don't create one in CLAUDE.md. Describe what IS, not what should be.
- **Don't include generic advice.** "Write clean code" and "follow best practices" help no one. Every line should be actionable and specific to THIS project.

## Success criteria

A good CLAUDE.md is one where:

1. An assistant reading it avoids at least one real mistake per session
2. Every section answers "what would an assistant get wrong without this?"
3. Nothing in it is already enforced by tools (linters, formatters, CI)
4. Build/run commands actually work when copy-pasted
5. It's short enough to read in 60 seconds (under ~200 lines for most projects)

## Examples

### Good: Minimal but high-signal

```markdown
## Project overview
E-commerce backend — REST API for product catalog and orders.

## Build & run
- `docker-compose up -d` — start Postgres + Redis
- `cargo run` — dev server on :8080
- `cargo test -- --test-threads=1` — tests need serial DB access

## Tech stack
Rust (axum), Postgres (sqlx), Redis (bb8 pool). No ORM — raw SQL via sqlx::query_as!.

## Code conventions
- Handler functions return `impl IntoResponse`, never `Response` directly
- Database migrations in `migrations/` — numbered, never edited after deploy
- Error types use `thiserror`, expose them in `src/error.rs` only

## Common pitfalls
- Tests share a database — run with `--test-threads=1` or they race
- Redis connections must be acquired via the pool, never created directly
- The `order_total` column is a generated field — don't try to INSERT it
```

### Bad: Bloated and obvious

```markdown
## Project overview
This is a full-stack web application built with modern technologies...

## Tech stack
- React 18 for the frontend
- Node.js for the backend
- PostgreSQL for data storage
- Redis for caching
- Docker for containerization

## Code conventions
- Use consistent indentation (2 spaces)
- Write meaningful variable names
- Add comments for complex logic
- Follow DRY principles
- Write unit tests for all features
- Use Prettier for code formatting
- Follow ESLint rules

[200 more lines of generic advice...]
```

The bad example is full of things the assistant already knows or tools already enforce. It adds noise, not signal.

## Bundled resources

This skill ships with the Karpathy behavioral guidelines as a foundation. When generating a CLAUDE.md, reference or include the guidelines from the parent plugin's `CLAUDE.md`. The four principles should appear in every generated CLAUDE.md — either as a brief reference block or woven into the project-specific instructions.

The canonical text lives at `../CLAUDE.md` relative to this skill's directory (it's the plugin root's CLAUDE.md). Read it when you need the exact wording.
